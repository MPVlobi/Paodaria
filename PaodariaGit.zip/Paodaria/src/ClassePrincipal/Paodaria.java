

package ClassePrincipal;
import conexoes.MySQL;
public class Paodaria {

    public static void main(String[] args) {
          MySQL mysql = new MySQL("localhost:3306","Paodaria" ,"root", "142536");
        mysql.conectaBanco();
       String cpf = "7879759";
        String nome = "FERNANDINHO NÃO VASCO";
        String email = "FERNANDINHO.oda@cassio.com";
        String telefone = "7777894549";
        String senha = "FERNANDINHO";
        String dataNascimento = "2000-06-06";
        
         String sql = "INSERT INTO cliente (Cpf_usuario, Nome_usuario, Email_usuario, telefone_usuario, senha_usuario, data_nascimento) " +
                     "VALUES ('" + cpf + "', '" + nome + "', '" + email + "', '" + telefone + "', '" + senha + "', '" + dataNascimento + "')";
     mysql.insertSQL(sql);
        
        mysql.fechaBanco();
    } 
   
}
